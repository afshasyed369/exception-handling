clas FinalExample{
	public static void main(String[] args) {
		final int x=100;
		x=200;//Compile time error
	}
}